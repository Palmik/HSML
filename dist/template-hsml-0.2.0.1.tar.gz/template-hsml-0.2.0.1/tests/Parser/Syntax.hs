module Parser.Syntax
( tests
) where

------------------------------------------------------------------------------
-- import           Data.Maybe
------------------------------------------------------------------------------
-- import qualified Text.Parsec.String     as P
-- import qualified Text.Parsec as P
------------------------------------------------------------------------------
import           Test.Framework
-- import           Test.Framework.Providers.QuickCheck2
-- import           Test.QuickCheck
------------------------------------------------------------------------------
-- import qualified Template.HSML.Internal.Types.Syntax  as I
-- import qualified Template.HSML.Internal.Parser.Syntax as I
------------------------------------------------------------------------------

tests :: [Test]
tests = []

{-
parse :: P.Parser a -> String -> Maybe a
parse p str = case P.parse p "" str of
                  Right x -> Just x
                  _       -> Nothing
-}

